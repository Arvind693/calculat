let num1=6;
let num2=2;


let add=()=>{
    return (num1+num2);
}
 module.exports=add;