let num1=6;
let num2=2;


let multi=()=>{
    return (num1*num2);
}
 module.exports=multi;