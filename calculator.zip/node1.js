let add=require("./calculator/add")
let divide=require("./calculator/divide")
let multi=require("./calculator/multi")
let sub=require("./calculator/sub")

let adds=add();
let divides=divide();
let multis=multi();
let subs=sub();

console.log(adds)
console.log(divides)
console.log(multis)
console.log(subs)
